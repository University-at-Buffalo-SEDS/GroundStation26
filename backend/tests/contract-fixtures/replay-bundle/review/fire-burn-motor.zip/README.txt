UB SEDS ground station — motor data export

Source: event.launch.2027-01-15_09-00-00_fire.db (capture)
Label: Launch
Mode: test_fire
Range: 2027-01-15T07:59:50Z .. 2027-01-15T08:00:20Z
Generated: 2026-01-01T00:00:00Z

Times: network_ms is UTC milliseconds on network time (the DAQ SD file's network-time rows and the station's source timestamps share it); t_s is seconds from the reference named in each file's header comment.

Files:
  motor_summary.json           burn report values, prediction, window, sources (JSON)
  motor_summary.txt            the same, readable
  thrust_curve.csv             thrust curve (t from ignition, N)
  predicted_thrust_curve.csv   predicted thrust curve
  loadcells_calibrated.csv     KG1000 + KG50 kg, DAQ SD merged, source per sample
  loadcells_raw.csv            KG1000/KG50 raw pin volts
  chamber_pt.csv               chamber PT psi, merged
  chamber_pt_raw.csv           chamber PT volts
  tank_pt.csv                  ox tank PT psi, merged
  tank_pt_raw.csv              ox tank PT raw
  temperatures.csv             temperatures
  valve_events.csv             valve open/close events
  daq_sd.csv                   every DAQ SD row in the range (merged sources)
  plots/*.svg                  thrust, chamber pressure, tank pressure, load cells
  report.html                  everything above in one page
  provenance.json              where the data came from

Note: PNG/PDF not requested.
