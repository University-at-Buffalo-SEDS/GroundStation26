UB SEDS ground station — flight summary export

Source: groundstation_recording_2026-01-01_00-00-00_000.db (legacy)
Label: groundstation_recording_2026-01-01_00-00-00_000.db
Mode: unknown
Range: 2026-01-01T00:00:30Z .. 2026-01-01T00:04:00Z
Generated: 2026-01-01T00:00:00Z

Times: network_ms is UTC milliseconds on network time (the DAQ SD file's network-time rows and the station's source timestamps share it); t_s is seconds from the reference named in each file's header comment.

Files:
  flight_summary.json          the flight summary (JSON)
  flight_summary.txt           the same, readable
  events.csv                   events with times from T-0 and from Launch acceptance
  altitude.csv                 FC Kalman and barometer altitude
  velocity.csv                 FC Kalman velocity, GS vehicle speed
  acceleration.csv             raw accelerometer magnitude
  gps_track.csv                GPS fixes
  plots/*.svg                  altitude and velocity with the events marked
  report.html                  everything above in one page
  provenance.json              where the data came from

Note: PNG/PDF not requested.
